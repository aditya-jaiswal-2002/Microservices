package com.hotel.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
//@Builder
@Entity
@Table(name = "Hotel_Microservice")
public class Hotel {

	@Id
	private String hotelId;
	private String name;
	private String location;
	private String about;
	
}
