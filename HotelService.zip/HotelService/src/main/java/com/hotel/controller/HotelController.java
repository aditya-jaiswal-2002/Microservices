package com.hotel.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotel.entity.Hotel;
import com.hotel.service.HotelService;

@RestController
@RequestMapping("/hotel")
public class HotelController {

	@Autowired
	private HotelService service;

	@GetMapping("/get")
	public ResponseEntity<List<Hotel>> getAllUser() {
		List<Hotel> list = service.getAllHotel();
		if (list != null)
			return new ResponseEntity<>(list, HttpStatus.ACCEPTED);

		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@GetMapping("/get/{hotelId}")
	public ResponseEntity<Hotel> getById(@PathVariable String hotelId) {
		Hotel hotel = service.getHotelById(hotelId);
		if (hotel != null)
			return new ResponseEntity<>(hotel, HttpStatus.ACCEPTED);
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

	}

	@PostMapping("/save")
	public ResponseEntity<String> saveUser(@RequestBody Hotel hotel) {
	
		 hotel.setHotelId(String.valueOf(UUID.randomUUID()));
//		hotel.setHotelId())
		if (service.addHotel(hotel))
			return new ResponseEntity<>("Hotel has been saved with id" + hotel.getHotelId(), HttpStatus.ACCEPTED);
		return new ResponseEntity<>("Hotel not saved there is some error in " + hotel.toString(), HttpStatus.BAD_REQUEST);
	}

	@PutMapping("/update/{hotelId}")
	public ResponseEntity<Hotel> updateUser(@PathVariable String hotelId, @RequestBody Hotel hotel) {
		return new ResponseEntity<>(service.updateHotelById(hotelId, hotel), HttpStatus.ACCEPTED);
	}

	@DeleteMapping("/delete/{hotelId}")
	public ResponseEntity<String> deleteUser(@PathVariable String hotelId) {
		if (service.deleteHotelById(hotelId))
			return new ResponseEntity<>("Hotel deleted ", HttpStatus.ACCEPTED);
		return new ResponseEntity<>("Hotel not deleted with id +${hotelId}", HttpStatus.BAD_REQUEST);

	}

}
