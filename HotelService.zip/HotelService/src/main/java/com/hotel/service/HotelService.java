package com.hotel.service;

import java.util.List;

import com.hotel.entity.Hotel;


public interface HotelService {

	List<Hotel> getAllHotel();

	Hotel getHotelById(String id);

	boolean addHotel(Hotel hotel);

	Hotel updateHotelById(String id, Hotel hotel);

	boolean deleteHotelById(String id);

}
