package com.hotel.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.entity.Hotel;
import com.hotel.repo.HotelReprositry;
import com.hotel.service.HotelService;

@Service
public class HotelServiceImplement implements HotelService {

	@Autowired
	private HotelReprositry reprositry;

	@Override
	public List<Hotel> getAllHotel() {
		return reprositry.findAll();
	}

	@Override
	public Hotel getHotelById(String id) {
		try {
			return reprositry.findById(id).orElse(null);
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public boolean addHotel(Hotel hotel) {
		try {
			
			reprositry.save(hotel);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Hotel updateHotelById(String id, Hotel hotel) {

		Hotel temphotel = reprositry.findById(id).orElse(null);
		temphotel.setAbout(hotel.getAbout());
		temphotel.setLocation(hotel.getLocation());
		temphotel.setName(hotel.getName());
		reprositry.save(temphotel);
		return temphotel;
	}

	@Override
	public boolean deleteHotelById(String id) {
		try {
			reprositry.delete(reprositry.findById(id).get());
			return true;
		} catch (Exception e) {
			return false;
		}

	}

}
