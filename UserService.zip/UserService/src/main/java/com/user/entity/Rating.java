package com.user.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Rating {

	private int userId;
	private int ratingId;
	private int ratingStar;
	private String feedback;
	private String hotelId;

	private Hotel hotel;
}
