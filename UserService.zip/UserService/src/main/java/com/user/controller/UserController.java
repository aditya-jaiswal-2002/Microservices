package com.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.user.entity.User;
import com.user.service.UserService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;
import jakarta.ws.rs.Path;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/get")
	public ResponseEntity<List<User>> getAllUser() {
		List<User> list = service.getAllUser();
		if (list != null)
			return new ResponseEntity<>(list, HttpStatus.ACCEPTED);

		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

//------------------------------By using restTemplate------------------------------
//	--------------------------------------------------------------------------
//	@GetMapping("/get/{userId}")
//	public ResponseEntity<User> getById(@PathVariable int userId) {
//		User user = service.getUserById(userId);
////		String baseUrl = "http://localhost:8083/rating/user/" + userId;
//		String baseUrl = "http://RATINGSERVICE/rating/user/" + userId;
//
//		if (user != null) {
//			Rating[] arr = restTemplate.getForObject(baseUrl, Rating[].class);
//			List<Rating> list=Arrays.stream(arr).toList();
//			List<Rating> list2=list.stream().map(rating -> {
//
////				String url = "http://localhost:8082/hotel/get/" + rating.getHotelId();
//				String url = "http://HOTELSERVICE/hotel/get/" + rating.getHotelId();
//				ResponseEntity<Hotel> hotel = restTemplate.getForEntity(url, Hotel.class);
//				Hotel hotel2 = hotel.getBody();
//				rating.setHotel(hotel2);
//				return rating;
//			}).collect(Collectors.toList());
//			user.setRatings(list2);
//			return new ResponseEntity<>(user, HttpStatus.ACCEPTED);
//		}
//		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//
//	}

//	@CircuitBreaker(name = "UserRatingHotel", fallbackMethod = "ratingHotelFallBack")
//	@Retry(name = "UserRatingHotel", fallbackMethod = "fallbackRating")
	@RateLimiter(name = "userRateLimiter", fallbackMethod = "dummyMethod")
	@GetMapping("/get/{userId}")
	public ResponseEntity<User> getById(@PathVariable int userId) {
		User user = service.getUserById(userId);

		if (user != null) {
			return new ResponseEntity<>(user, HttpStatus.ACCEPTED);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

	}

	public ResponseEntity<String> dummyMethod(@PathVariable int userId, Exception exception) {
		System.out.println("dummy method");
		return new ResponseEntity<String>("Dummy MEthod", HttpStatus.BAD_GATEWAY);
	}

	public ResponseEntity<User> ratingHotelFallBack(int userId, Exception exception) {
		System.out.println("hihihihihihi/n /n /n \n \n \n");
		System.err.println(exception.getMessage());
		User dummyUser = new User(1, "dummy anme", "dummy mail", "dummy hu", null);
		return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(dummyUser);
	}

	int count = 0;

	public ResponseEntity<String> fallbackRating(int userI, Exception exception) {
		count++;
		System.out.println("hihihihihihi/n /n /n \n \n \n  " + count++);
		return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body("Error in geting User ID");
	}

	@PostMapping("/save")
	public ResponseEntity<String> saveUser(@RequestBody User user) {
		if (service.addUser(user))
			return new ResponseEntity<>("User has been saved with id" + user.getUserId(), HttpStatus.ACCEPTED);
		return new ResponseEntity<>("User not saved there is some error in " + user.toString(), HttpStatus.BAD_REQUEST);
	}

	@PutMapping("/update/{userId}")
	public ResponseEntity<User> updateUser(@PathVariable int userId, @RequestBody User user) {
		return new ResponseEntity<>(service.updateUserBYId(userId, user), HttpStatus.ACCEPTED);
	}

	@DeleteMapping("/delete/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable int userId) {
		if (service.deleteUserbyId(userId))
			return new ResponseEntity<>("User deleted ", HttpStatus.ACCEPTED);
		return new ResponseEntity<>("User not deleted with id +${userId}", HttpStatus.BAD_REQUEST);

	}

}
