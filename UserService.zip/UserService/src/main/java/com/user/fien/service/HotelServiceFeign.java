package com.user.fien.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.user.entity.Hotel;

@FeignClient(name = "HotelService")
public interface HotelServiceFeign {

	@GetMapping("/hotel/get/{hotelId}")
	public Hotel getHotel(@PathVariable String hotelId);
}
