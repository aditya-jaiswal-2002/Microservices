package com.user.fien.rating;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.user.entity.Rating;

@FeignClient(name = "RatingService")
public interface FeignRatingService {

	@GetMapping("/rating/user/{ratingId}")
	public List<Rating> getRatingById(@PathVariable int ratingId);
}
