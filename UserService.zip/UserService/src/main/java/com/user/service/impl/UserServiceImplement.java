package com.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.entity.Hotel;
import com.user.entity.Rating;
import com.user.entity.User;
import com.user.fien.rating.FeignRatingService;
import com.user.fien.service.HotelServiceFeign;
import com.user.repo.UserReprositry;
import com.user.service.UserService;

@Service
public class UserServiceImplement implements UserService {

	@Autowired
	private UserReprositry reprositry;
	@Autowired 
	private FeignRatingService ratingService;
	@Autowired
	private HotelServiceFeign serviceFeign;
	@Override
	public List<User> getAllUser() {
		return reprositry.findAll();
	}

//	@Override
//	public User getUserById(int id) {
//		try {
//			return reprositry.findById(id).orElse(null);
//		} catch (Exception e) {
//			return null;
//		}
//	}
	@Override
	public User getUserById(int id) {
		try {
			User user=reprositry.findById(id).orElse(null);
//			Rating ratig=new Rating(1, 1, 5, "Hotel is good Enough", "b852d10c-65be-4bf2-b0e4-0bf16e6ec176",null);
//			List<Rating> ratings=new ArrayList<>();
//			ratings.add(ratig);
			
			List<Rating> ratings=ratingService.getRatingById(id);
			
			for (Rating rating : ratings) {
				
				Hotel hotel=serviceFeign.getHotel(rating.getHotelId());
				rating.setHotel(hotel);
			}
			user.setRatings(ratings);
			return user;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public boolean addUser(User user) {
		try {
			reprositry.save(user);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public User updateUserBYId(int id, User user) {

		User tempUser = reprositry.findById(id).orElse(null);
		tempUser.setAbout(tempUser.getAbout());
		tempUser.setEmail(user.getEmail());
		tempUser.setName(user.getName());
		reprositry.save(tempUser);
		return tempUser;
	}

	@Override
	public boolean deleteUserbyId(int id) {
		try {
			reprositry.delete(reprositry.findById(id).get());
			return true;
		} catch (Exception e) {
			return false;
		}

	}

}
