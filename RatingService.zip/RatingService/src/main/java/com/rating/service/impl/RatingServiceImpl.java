package com.rating.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rating.entity.Rating;
import com.rating.repo.RatingRepository;
import com.rating.service.RatingService;

@Service
public class RatingServiceImpl implements RatingService {

	@Autowired
	RatingRepository repository;

	@Override
	public List<Rating> getAllRating() {

		return repository.findAll();

	}

	@Override
	public List<Rating> getByUserId(int id) {

		return repository.findByUserId(id);
	}

	@Override
	public Rating addRating(Rating rating) {

		try {
			this.repository.save(rating);
			System.out.println("Saving rating" + rating.toString());
			return rating;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public List<Rating> getByHotelId(String id) {
		return repository.findByHotelId(id);
	}

}
