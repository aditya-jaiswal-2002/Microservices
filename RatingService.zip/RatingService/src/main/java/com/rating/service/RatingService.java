package com.rating.service;

import java.util.List;

import com.rating.entity.Rating;

public interface RatingService {

	List<Rating> getAllRating();

	List<Rating> getByUserId(int id);

	Rating addRating(Rating rating);

	List<Rating> getByHotelId(String id);

}
