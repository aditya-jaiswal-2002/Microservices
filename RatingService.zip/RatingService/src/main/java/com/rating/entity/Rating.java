package com.rating.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document("Rating_Microservice")
public class Rating {

	@Id
	private int ratingId;
	private String feedback;
	private int ratingStar;
	private String hotelId;
	private int userId;
}
