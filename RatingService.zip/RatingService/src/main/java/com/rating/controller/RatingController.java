package com.rating.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rating.entity.Rating;
import com.rating.service.RatingService;

@RestController
@RequestMapping("/rating")
public class RatingController {

	static int id = 0;
	@Autowired
	private RatingService service;

	@GetMapping("/get")
	public ResponseEntity<List<Rating>> getAllRatings() {
		List<Rating> list = service.getAllRating();
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(list);
	}

	@PostMapping("/save")
	public ResponseEntity<Rating> addRating(@RequestBody Rating rating) {
		rating.setRatingId(id++);
		Rating rate = service.addRating(rating);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(rate);
	}

	@GetMapping("/user/{userId}")
	public ResponseEntity<List<Rating>> getByUserId(@PathVariable int userId) {
		return new ResponseEntity<List<Rating>>(service.getByUserId(userId), HttpStatusCode.valueOf(200));
	}

	@GetMapping("/hotel/{hotelId}")
	public ResponseEntity<List<Rating>> getByHotelId(@PathVariable String hotelId) {
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(service.getByHotelId(hotelId));
	}

}
