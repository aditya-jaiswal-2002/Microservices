package com.cloud.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.annotation.RegisteredOAuth2AuthorizedClient;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.models.OathResponse;

import jakarta.ws.rs.GET;

@RestController
@RequestMapping("/oath")
public class OathController {

	private Logger logger = LoggerFactory.getLogger(OathController.class);

	@GetMapping("/login")
	public ResponseEntity<OathResponse> login(
			@RegisteredOAuth2AuthorizedClient("okta") OAuth2AuthorizedClient authorizedClient,
			@AuthenticationPrincipal OidcUser oidcUser, Model model) {

		return null;
	}
}
